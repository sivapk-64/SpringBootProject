package com.example.projectdatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectdatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
